// import React from "react";
// import styled from 'styled-Components';
// import AdicionarTexto from './Components/AdicionarTexto/AdicionarTexto'

// const ContainerMensagem = styled.div
// width: 100%;
// heigth: 100%;
// display: flex;0
// flex-direction: column;
// justify-content: flex-start;
// align-items: flex-start;
// background-color: #fff;
// border-redius: 10px;
// box-shadow: 0px 0px 10px #000,
// padding: 10px;
// margin-bottom: 10px;
// &:hover {
//   cursor: Pointer;
// }
// ;


// enviarMensagem = () => {
//   const novaMensagem = {
//     nome: `${this.state.inputNomeUsuario}:`,
//     mensagem: this.state.inputMensagem
//   }
//   const novoMensagens = [...this.state.mensagens, novaMensagem]
//   this.setState({mensagens: novoMensagens});
//   this.setState({inputMensagem: ""});
// }

//   const apareceMensagens = this.state.mensagem.map ((item) => {
//     return
//     <div>
//       <p>{item.nome} : {item.mensagem}</p>
//     </div>  
//   })




// export default AdicionarTexto;
