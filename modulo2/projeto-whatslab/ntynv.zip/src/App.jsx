// import AdicionarTexto from "./components/AdicionarTexto";
import React from "react";

class App extends React.Component {
  state = {
    inputUsuario: "",
    inputMensagem: ""
  };

  onchangeInputUsuario = (event) => {
    this.setState({inputUsuario: event.target.value});
  };

  onchangeInputMensagem = (event) => {
    this.setState({inputMensagem: event.target.value});
  };

  limparInputs = () => {
    this.setState({
    inputUsuario: "",
    inputMensagem: "",
    })
  }

  render() {
    return (
      // <ContainerMensagem>

        <div>
          <input
          value={this.state.inputUsuario}
          onChange={this.onchangeInputUsuario}
          placeholder={"Nome"}
          />

          <input
          value={this.state.inputMensagem}
          onChange={this.onchangeInputMensagem}
          placeholder={"Mensagem"}
          />

          <button onClick={this.limparInputs}>Enviar</button>
          <p>{this.state.inputUsuario}</p>
          <p>{this.state.inputMensagem}</p>

        </div>

      // </ContainerMensagem>
    );
  }
}

export default App;