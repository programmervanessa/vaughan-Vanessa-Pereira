import axios from "axios";
import React from 'react'
import "./styles.css";

export default class App extends React.Component {
  state={
    AllUsers: [],
    inputValue: ""
  }

  componentDidMount()
  {
    getAllUsers()
    this.getAllUsers()
  }

  handleInput=(event)=>{
    this.setState({inputValue:event.target.value})
  }

  getAllUsers = () => {
    axios.get(
        "https://us-central1-labenu-apis.cloudfunctions.net/labenusers/users",
        {
          Headers: {
            Authorization: "vanessa-dias-vaughan"
          }
        }
      )
  
      .then((response)=> {
        // this.setState({AllUsers:response.data.result.list})
        alert("Usuário criado com sucesso!".response.data)
      })
  
      .catch((error) => {
        alert("Não foi possível criar usuário", 
        error.response.data);
      });
  };

creatUsers=()=>{

const url = 
  "https://us-central1-labenu-apis.cloudfunctions.net/labenusers/users"


const body = {
  name: this.state.inputValue,
  email: this.state.inputValue,
}
  

const axiosConfig = {

  Headers:

  {
  Authorization:"vanessa-dias-vaughan"
  }

axios.post(url,body,axiosConfig)

.then((resp)=>{
  alert("Usuário adicionado com sucesso!")  
  this.setState({inputValue: ""})
  this.creatUsers()
})

.catch((err)=>{
   alert("Por favor, preencha todos os campos para adicionar usuário")
})
}
// creatUsers()

  render(){
    const novoUsuario= this.state.creatUsers.map(
      (creatUsers)=>{
        return(
          <div>
            <p>{creatUsers.name}</p>
          </div>
        )
      }
    )
    console.log("estado", this.state)
    return (
      <div className="App">
        <input
        placeholder= "Name"
        value={this.state.inputValue}
        onChange={this.handleInput}
        />
        <input
        placeholder= "E-mail"
        value={this.state.inputValue}
        onChange={this.handleInput}
        />
        <button onClick={this.creatUsers()}
        >Criar Usuário</button>
        {AllUsers}
        {creatUsers}
        </div>
    );
  }
}






